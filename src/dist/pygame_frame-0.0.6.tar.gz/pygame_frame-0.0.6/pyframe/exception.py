class ArgumentError(Exception) :
    pass
import os,sys
local_dir = os.path.dirname( os.path.realpath( sys.argv[0] ) )+"\\"